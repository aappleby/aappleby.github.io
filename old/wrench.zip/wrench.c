/*
 * AVRGCC1.c
 *
 * Created: 8/6/2011 12:04:17 AM
 *  Author: aappleby
 */

//#define F_CPU 20000000

// internal RC oscillator trimmed up all the way = 13.25 mhz - ~75 ns/clock

#define F_CPU 13250000

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define ATTINY84

//-----------------------------------------------------------------------------
// macros

#define bit(A)   (1 << A)
#define sbi(p,b) { p |= (unsigned char)bit(b); }
#define cbi(p,b) { p &= (unsigned char)~bit(b); }
#define tbi(p,b) { p ^= (unsigned char)bit(b); }
#define gbi(p,b) (p & (unsigned char)bit(b))

//-----------------------------------------------------------------------------
// bridge control macros

#define LOW1  ( bit(6) | bit(7) )
#define DEAD1 ( bit(6) | 0      )
#define HIGH1 ( 0      | 0      )

#define LOW2  ( bit(4) | bit(5) )
#define DEAD2 ( 0      | bit(5) )
#define HIGH2 ( 0      | 0      )

//-----------------------------------------------------------------------------

void initComparator ( void )
{
  // turn off internal reference
  cbi(ADCSRB,ACME);

	// turn off digital input buffer for comparator pins
  sbi(DIDR0,ADC1D);
  sbi(DIDR0,ADC2D);
}

//-----------------------------------------------------------------------------

// A0 - direction
// A1 - current sense feedback
// A2 - current set
// A3 - !enable
// A4 - scl
// A5 - miso

// A6 - mosi
// A7 - low2
// B2 - fault
// B3 - reset
// B1 - direction
// B0 - !enable

void initPorts ( void )
{
  // pins 4/5/6/7 of port A are our bridge control pins

  PORTA = LOW1 | LOW2;
  DDRA = bit(0) | bit(3) | bit(4) | bit(5) | bit(6) | bit(7);

  // pin 2 of port B is our status LED
  PORTB = 0;
  DDRB = bit(2);
}

//-----------------------------------------------------------------------------

// 255 * 75 * 5 = 95 us per timeout.
// 100 timeouts = 9.5 ms until fault latched

#define TIMEOUT_MAX 255
#define FAULT_MAX 100

int main(void)
{
	OSCCAL = 0xFF;

  // pin 2 of port B is our status LED
  /*
  PORTB = 0;
  DDRB = bit(2);

	while(1)
	{
	  while((PINB & bit(0)) != 0);
		PORTB = 0x04;
		_delay_ms(100);
		PORTB = 0x00;
		_delay_ms(100);
	}
	*/

  // On startup the p-mos gate is stuck low due to the coupling capacitance,
  // wait for it to charge and then turn on "ready" LED
  _delay_ms(20);

  initPorts();
  initComparator();

  uint8_t timeout = 255;
  uint8_t fault = 0;

  while(1)
  {
	  // spin-wait while disabled
	  while((PINB & bit(0)) != 0);

	  // switch modes if A0 high
	  if((PINB & bit(1)) != 0) goto start2;

start1:
    // 150 ns dead time, then high + blanking interval
    PORTA = DEAD1 | LOW2; asm("nop"); asm("nop"); asm("nop");
    PORTA = HIGH1 | LOW2; asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");

    // wait for comparator or timeout
	  timeout = TIMEOUT_MAX;
    do { if((ACSR & bit(ACO)) == 0) break; } while(--timeout);

    // dead time, then low
    PORTA = DEAD1 | LOW2; asm("nop"); asm("nop"); asm("nop");
    PORTA = LOW1  | LOW2;

	  // if we hit the timeout, record a fault and flash the fault pin
	  if(timeout == 0)
	  {
		  // and if we hit enough faults in a row, signal and spin until enable pin toggled
		  fault++;

      /*
		  if(fault >= FAULT_MAX)
		  {
		    while((PINB & bit(0)) == 0);
		    while((PINB & bit(0)) != 0);
			  fault = 0;
		  }
		  */
	  }
	  else
	  {
		  if(fault) fault--;
		  //fault = 0;
	  }

    if(fault)
	  {
		  sbi(PORTB,2);
	  }
	  else
	  {
		  cbi(PORTB,2);
	  }


	  // fixed off-time
	  _delay_us(10);
	}

  while(1)
  {
	  // spin-wait while disabled
	  while((PINB & bit(0)) != 0);

	  // switch modes if A0 low
	  if((PINB & bit(1)) == 0) goto start1;

start2:
    // 150 ns dead time, then high + blanking interval
    PORTA = LOW1 | DEAD2; asm("nop"); asm("nop"); asm("nop");
    PORTA = LOW1 | HIGH2; asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop"); asm("nop");

    // wait for comparator or timeout
	  timeout = TIMEOUT_MAX;
    do { if((ACSR & bit(ACO)) == 0) break; } while(--timeout);

    // dead time, then low
    PORTA = LOW1 | DEAD2; asm("nop"); asm("nop"); asm("nop");
    PORTA = LOW1 | LOW2;

	  // if we hit the timeout, record a fault and flash the fault pin
	  if(timeout == 0)
	  {
		  // and if we hit enough faults in a row, signal and spin until enable pin toggled
		  fault++;

      /*
		  if(fault >= FAULT_MAX)
		  {
		    while((PINB & bit(0)) == 0);
		    while((PINB & bit(0)) != 0);
			  fault = 0;
		  }
		  */
	  }
	  else
	  {
		  if(fault) fault--;
		  //fault = 0;
	  }

    if(fault)
	  {
		  sbi(PORTB,2);
	  }
	  else
	  {
		  cbi(PORTB,2);
	  }

	  // fixed off-time
	  _delay_us(10);
	}
}

